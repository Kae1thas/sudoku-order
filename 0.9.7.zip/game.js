const STORAGE_KEYS = {
  coins: "sudoku_order_coins",
  progress: "sudoku_order_progress_v4",
  lang: "sudoku_order_lang",
};

const DEBUG_PARAMS = new URLSearchParams(window.location.search);
const DEBUG_MODE =
  DEBUG_PARAMS.has("debug") ||
  DEBUG_PARAMS.has("debug-mode") ||
  window.location.hash.includes("debug=1") ||
  localStorage.getItem("sudoku_debug") === "1";

const SUPPORTED_LANGS = ["ru", "en"];

function normalizeLang(lang) {
  const value = String(lang || "ru").toLowerCase().slice(0, 2);
  return SUPPORTED_LANGS.includes(value) ? value : "en";
}

function hasExplicitLanguageOverride() {
  const params = new URLSearchParams(window.location.search);
  return params.has("lang");
}

function detectInitialLang() {
  const params = new URLSearchParams(window.location.search);
  return normalizeLang(
    params.get("lang")
    || localStorage.getItem(STORAGE_KEYS.lang)
    || document.documentElement.lang
    || navigator.language
    || "ru"
  );
}

let currentLang = detectInitialLang();

const I18N = {
  ru: {
    title: "Судоку Код Порядка",
    subtitle: "Лёгкая браузерная головоломка с классическим и бесконечным режимом.",
    time: "Время",
    coins: "Монеты",
    price: "Цена",
    difficulty: "Сложность",
    theme: "Тема",
    language: "Язык",
    langMeta: "Русский / English",
    langBadge: "RU",
    endlessMode: "Бесконечный",
    progress: "Прогресс",
    actions: "Действия",
    newGame: "Новая игра",
    pause: "Пауза",
    resume: "Продолжить",
    erase: "Стереть",
    clearNotes: "Очистить заметки",
    hint: "Подсказка",
    surrender: "Сдаться",
    rules: "Правила",
    rulesMeta: "Краткая справка по игре",
    open: "Открыть",
    close: "Закрыть",
    rule1: "Заполни все пустые клетки символами из нижней панели.",
    rule2: "В строке, столбце и выделенном блоке символы не должны повторяться.",
    rule3: "В обычном режиме ошибка снимает жизнь. В бесконечном режиме ошибки считаются после полной проверки.",
    rule4: "Заметки помогают временно записывать варианты внутри клетки.",
    gameOverTitle: "Жизни закончились",
    gameOverText: "Можно продолжить за монеты или начать заново.",
    gameOverNote: "Продолжение за монеты доступно в рамках игрового прогресса.",
    buyLife: "Продолжить за 50 монет",
    restart: "Рестарт",
    winTitle: "Уровень пройден",
    winDefaultText: "Отлично. Победа засчитана в прогресс.",
    nextLevel: "Открыть следующий уровень",
    playAgain: "Играть снова",
    surrenderTitle: "Ты сдался",
    surrenderText: "Поле раскрыто полностью. Это поражение, но можешь спокойно посмотреть решение.",
    endlessFilled: "Поле заполнено.",
    continueFixing: "Продолжить исправлять",
    lives: "Жизни",
    mode: "Режим",
    locked: "Закрыт",
    on: "Вкл",
    off: "Выкл",
    lightTheme: "Светлая",
    darkTheme: "Тёмная",
    opensAfter5Wins: "После 5 побед",
    noLivesCheckAtEnd: "Проверка в конце",
    field: "поле",
    endlessShort: "бесконечный",
    endlessSuffix: "Без жизней: ошибки считаются после полного заполнения.",
    firstHintFree: "1-я подсказка бесплатно",
    nextHint: "Следующая подсказка: 25 монет",
    coinsShort: "мон.",
    endlessOpen: "∞ открыт",
    toInfinity: "до ∞",
    wins: "Побед",
    needUnlock: "Нужно открыть",
    notesOn: "Заметки: вкл",
    notesOff: "Заметки: выкл",
    endlessPerfect: "Поле заполнено без ошибок. Это чистое прохождение бесконечного режима.",
    endlessErrors: (errors) => `Поле заполнено. Ошибок: ${errors}. Можешь продолжить исправлять или начать заново.`,
    notEnoughCoinsHint: "Недостаточно монет для подсказки. Нужно 25 монет.",
    notEnoughCoinsContinue: "Недостаточно монет для продолжения. Нужно 50 монет.",
    winMessage: (title, reward, wins) => `Сложность «${title}» пройдена. Получено ${reward} монет. Побед на этом уровне: ${wins}.`,
    endlessLockedMessage: (title) => `Бесконечный режим для сложности «${title}» откроется после 5 побед на ней.`,
  },
  en: {
    title: "Sudoku Code of Order",
    subtitle: "A light browser puzzle with classic and endless modes.",
    time: "Time",
    coins: "Coins",
    price: "Price",
    difficulty: "Difficulty",
    theme: "Theme",
    language: "Language",
    langMeta: "Русский / English",
    langBadge: "EN",
    endlessMode: "Endless",
    progress: "Progress",
    actions: "Actions",
    newGame: "New Game",
    pause: "Pause",
    resume: "Resume",
    erase: "Erase",
    clearNotes: "Clear Notes",
    hint: "Hint",
    surrender: "Give Up",
    rules: "Rules",
    rulesMeta: "Quick game help",
    open: "Open",
    close: "Close",
    rule1: "Fill every empty cell with symbols from the lower panel.",
    rule2: "Symbols must not repeat in any row, column, or highlighted block.",
    rule3: "In classic mode, mistakes cost lives. In endless mode, mistakes are counted after the final check.",
    rule4: "Notes help you keep temporary candidates inside cells.",
    gameOverTitle: "Out of Lives",
    gameOverText: "You can continue for coins or start over.",
    gameOverNote: "Continuing for coins is available as part of game progress.",
    buyLife: "Continue for 50 coins",
    restart: "Restart",
    winTitle: "Level Complete",
    winDefaultText: "Great. The win has been added to your progress.",
    nextLevel: "Open Next Level",
    playAgain: "Play Again",
    surrenderTitle: "You Gave Up",
    surrenderText: "The board is fully revealed. This counts as a loss, but you can review the solution.",
    endlessFilled: "The board is filled.",
    continueFixing: "Keep Fixing",
    lives: "Lives",
    mode: "Mode",
    locked: "Locked",
    on: "On",
    off: "Off",
    lightTheme: "Light",
    darkTheme: "Dark",
    opensAfter5Wins: "After 5 wins",
    noLivesCheckAtEnd: "Final check",
    field: "board",
    endlessShort: "endless",
    endlessSuffix: "No lives: mistakes are counted after the board is filled.",
    firstHintFree: "1st hint is free",
    nextHint: "Next hint: 25 coins",
    coinsShort: "coins",
    endlessOpen: "∞ open",
    toInfinity: "to ∞",
    wins: "Wins",
    needUnlock: "Locked",
    notesOn: "Notes: on",
    notesOff: "Notes: off",
    endlessPerfect: "The board is complete with no mistakes. This is a clean endless-mode run.",
    endlessErrors: (errors) => `The board is filled. Mistakes: ${errors}. You can keep fixing it or start over.`,
    notEnoughCoinsHint: "Not enough coins for a hint. You need 25 coins.",
    notEnoughCoinsContinue: "Not enough coins to continue. You need 50 coins.",
    winMessage: (title, reward, wins) => `Difficulty “${title}” complete. You earned ${reward} coins. Wins on this level: ${wins}.`,
    endlessLockedMessage: (title) => `Endless mode for “${title}” opens after 5 wins on this difficulty.`,
  },
};

const DIFFICULTY_I18N = {
  ru: {
    easy: { title: "Лёгкий", description: "Спокойный старт и ровное поле 9×9." },
    medium: { title: "Средний", description: "Чуть плотнее и требовательнее." },
    hard: { title: "Сложный", description: "Меньше подсказок, больше риска." },
    expert: { title: "Эксперт", description: "Большое поле 16×16 с символами 1–G." },
    abyss: { title: "Бездна", description: "Тяжёлый режим 16×16 для упорных." },
  },
  en: {
    easy: { title: "Easy", description: "A calm start on a smooth 9×9 board." },
    medium: { title: "Medium", description: "A denser and more demanding puzzle." },
    hard: { title: "Hard", description: "Fewer clues and more risk." },
    expert: { title: "Expert", description: "A large 16×16 board with symbols 1–G." },
    abyss: { title: "Abyss", description: "A tough 16×16 mode for persistent players." },
  },
};

function t(key, ...args) {
  const value = I18N[currentLang]?.[key] ?? I18N.ru[key] ?? key;
  return typeof value === "function" ? value(...args) : value;
}

function getDifficultyTitle(diff) {
  return DIFFICULTY_I18N[currentLang]?.[diff.id]?.title
    ?? DIFFICULTY_I18N.ru[diff.id]?.title
    ?? diff.title
    ?? diff.id;
}

function getDifficultyDescription(diff) {
  return DIFFICULTY_I18N[currentLang]?.[diff.id]?.description
    ?? DIFFICULTY_I18N.ru[diff.id]?.description
    ?? diff.description
    ?? "";
}

function applyLanguage(lang) {
  currentLang = normalizeLang(lang);
  document.documentElement.lang = currentLang;
  document.body.dataset.lang = currentLang;
  document.title = t("title");

  document.querySelectorAll("[data-i18n]").forEach((element) => {
    const key = element.getAttribute("data-i18n");
    if (key) element.textContent = t(key);
  });

  dom?.boardWrap?.setAttribute("data-pause-label", t("pause"));
}


const DIFFICULTIES = [
  {
    id: "easy",
    size: 9,
    removeCount: 34,
    reward: 30,
    unlockWinsRequired: 0,
  },
  {
    id: "medium",
    size: 9,
    removeCount: 42,
    reward: 45,
    unlockWinsRequired: 5,
  },
  {
    id: "hard",
    size: 9,
    removeCount: 50,
    reward: 60,
    unlockWinsRequired: 5,
  },
  {
    id: "expert",
    size: 16,
    removeCount: 96,
    reward: 100,
    unlockWinsRequired: 5,
  },
  {
    id: "abyss",
    size: 16,
    removeCount: 122,
    reward: 140,
    unlockWinsRequired: 5,
  },
];

const SYMBOL_SETS = {
  4: ["1", "2", "3", "4"],
  9: ["1", "2", "3", "4", "5", "6", "7", "8", "9"],
  16: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G"],
};

const SUBGRID_MAP = {
  4: { rows: 2, cols: 2 },
  9: { rows: 3, cols: 3 },
  16: { rows: 4, cols: 4 },
};

const state = {
  difficultyIndex: 0,
  board: [],
  solution: [],
  fixed: [],
  notes: [],
  selected: null,
  notesMode: false,
  lives: 3,
  gameOver: false,
  isPaused: false,
  pauseReason: null,
  timerSeconds: 0,
  timerId: null,
  timerStarted: false,
  coins: loadCoins(),
  progress: loadProgress(),
  hintsUsedThisGame: 0,
  surrendered: false,
  isEndless: false,
  debugUnlockAll: false,
};

const dom = {
  board: document.getElementById("board"),
  boardWrap: document.getElementById("boardWrap"),
  boardTitle: document.getElementById("boardTitle"),
  boardSubtitle: document.getElementById("boardSubtitle"),
  hintMeta: document.getElementById("hintMeta"),
  timeValue: document.getElementById("timeValue"),
  mobileTimeValue: document.getElementById("mobileTimeValue"),
  modeStatLabel: document.getElementById("modeStatLabel"),
  modeValue: document.getElementById("modeValue"),
  coinsValue: document.getElementById("coinsValue"),
  modalCoinsValue: document.getElementById("modalCoinsValue"),
  difficultyList: document.getElementById("difficultyList"),
  progressList: document.getElementById("progressList"),
  numberPad: document.getElementById("numberPad"),
  notesBtn: document.getElementById("notesBtn"),
  newGameBtn: document.getElementById("newGameBtn"),
  pauseBtn: document.getElementById("pauseBtn"),
  modeBtn: document.getElementById("modeBtn"),
  modeBtnMeta: document.getElementById("modeBtnMeta"),
  modeBtnBadge: document.getElementById("modeBtnBadge"),
  themeBtn: document.getElementById("themeBtn"),
  themeBtnMeta: document.getElementById("themeBtnMeta"),
  themeBtnBadge: document.getElementById("themeBtnBadge"),
  langBtn: document.getElementById("langBtn"),
  langBtnMeta: document.getElementById("langBtnMeta"),
  langBtnBadge: document.getElementById("langBtnBadge"),
  eraseBtn: document.getElementById("eraseBtn"),
  clearNotesBtn: document.getElementById("clearNotesBtn"),
  hintBtn: document.getElementById("hintBtn"),
  surrenderBtn: document.getElementById("surrenderBtn"),
  notification: document.getElementById("notification"),
  overlay: document.getElementById("overlay"),
  rulesBtn: document.getElementById("rulesBtn"),
  rulesModal: document.getElementById("rulesModal"),
  closeRulesBtn: document.getElementById("closeRulesBtn"),
  gameOverModal: document.getElementById("gameOverModal"),
  winModal: document.getElementById("winModal"),
  surrenderModal: document.getElementById("surrenderModal"),
  endlessResultModal: document.getElementById("endlessResultModal"),
  endlessResultText: document.getElementById("endlessResultText"),
  continueEndlessBtn: document.getElementById("continueEndlessBtn"),
  restartAfterEndlessBtn: document.getElementById("restartAfterEndlessBtn"),
  buyLifeBtn: document.getElementById("buyLifeBtn"),
  restartFromLoseBtn: document.getElementById("restartFromLoseBtn"),
  nextDifficultyBtn: document.getElementById("nextDifficultyBtn"),
  restartAfterWinBtn: document.getElementById("restartAfterWinBtn"),
  restartAfterSurrenderBtn: document.getElementById("restartAfterSurrenderBtn"),
  winText: document.getElementById("winText"),
};

function loadCoins() {
  const raw = localStorage.getItem(STORAGE_KEYS.coins);
  const parsed = Number(raw);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : 120;
}

function saveCoins() {
  localStorage.setItem(STORAGE_KEYS.coins, String(state.coins));
  syncYandexSave();
}

function getEmptyProgress() {
  return {
    easy: 0,
    medium: 0,
    hard: 0,
    expert: 0,
    abyss: 0,
  };
}

function loadProgress() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.progress);
    if (!raw) {
      return getEmptyProgress();
    }
    const parsed = JSON.parse(raw);
    return {
      easy: Number(parsed.easy) || 0,
      medium: Number(parsed.medium) || 0,
      hard: Number(parsed.hard) || 0,
      expert: Number(parsed.expert) || 0,
      abyss: Number(parsed.abyss) || 0,
    };
  } catch {
    return getEmptyProgress();
  }
}

function saveProgress() {
  localStorage.setItem(STORAGE_KEYS.progress, JSON.stringify(state.progress));
  syncYandexSave();
}

function getCurrentDifficulty() {
  return DIFFICULTIES[state.difficultyIndex];
}

function getSymbols(size) {
  return SYMBOL_SETS[size];
}

function getPrevDifficulty(index) {
  if (index <= 0) return null;
  return DIFFICULTIES[index - 1];
}

function isDifficultyUnlocked(index) {
  if (state.debugUnlockAll) return true;

  if (index === 0) return true;
  const prev = getPrevDifficulty(index);
  if (!prev) return true;
  return (state.progress[prev.id] || 0) >= 5;
}

function isEndlessUnlockedForIndex(index) {
  if (state.debugUnlockAll) return true;

  const diff = DIFFICULTIES[index];
  return (state.progress[diff.id] || 0) >= 5;
}

function isCurrentEndlessUnlocked() {
  return isEndlessUnlockedForIndex(state.difficultyIndex);
}

function getDifficultyProgressText(index) {
  if (index === 0) {
    return `${Math.min(state.progress.easy || 0, 5)}/5`;
  }

  const prev = getPrevDifficulty(index);
  const current = state.progress[prev.id] || 0;
  return `${Math.min(current, 5)}/5`;
}

function shuffle(array) {
  const copy = [...array];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function createRange(n) {
  return Array.from({ length: n }, (_, i) => i);
}

function pattern(r, c, base) {
  return (base * (r % base) + Math.floor(r / base) + c) % (base * base);
}

function generateSolvedBoard(size) {
  const sub = SUBGRID_MAP[size];
  const base = sub.rows;
  const symbols = getSymbols(size);

  const rows = [];
  shuffle(createRange(base)).forEach((band) => {
    shuffle(createRange(base)).forEach((rowInBand) => {
      rows.push(band * base + rowInBand);
    });
  });

  const cols = [];
  shuffle(createRange(base)).forEach((stack) => {
    shuffle(createRange(base)).forEach((colInStack) => {
      cols.push(stack * base + colInStack);
    });
  });

  const shuffledSymbols = shuffle(symbols);
  return rows.map((r) => cols.map((c) => shuffledSymbols[pattern(r, c, base)]));
}

function deepCopyGrid(grid) {
  return grid.map((row) => [...row]);
}

function createEmptyNotes(size) {
  return Array.from({ length: size }, () =>
    Array.from({ length: size }, () => new Set())
  );
}

function getSubgridBounds(size, row, col) {
  const sub = SUBGRID_MAP[size];
  const startRow = Math.floor(row / sub.rows) * sub.rows;
  const startCol = Math.floor(col / sub.cols) * sub.cols;
  return {
    startRow,
    endRow: startRow + sub.rows - 1,
    startCol,
    endCol: startCol + sub.cols - 1,
  };
}

function getMinClueConfig(difficultyId) {
  switch (difficultyId) {
    case "easy":
      return { row: 3, col: 3, box: 3 };
    case "medium":
      return { row: 2, col: 2, box: 2 };
    case "hard":
      return { row: 1, col: 1, box: 1 };
    default:
      return { row: 1, col: 1, box: 1 };
  }
}

function passesClueDistribution(board, config) {
  const size = board.length;
  const sub = SUBGRID_MAP[size];

  for (let row = 0; row < size; row += 1) {
    let count = 0;
    for (let col = 0; col < size; col += 1) {
      if (board[row][col] !== "") count += 1;
    }
    if (count < config.row) return false;
  }

  for (let col = 0; col < size; col += 1) {
    let count = 0;
    for (let row = 0; row < size; row += 1) {
      if (board[row][col] !== "") count += 1;
    }
    if (count < config.col) return false;
  }

  for (let boxRow = 0; boxRow < size; boxRow += sub.rows) {
    for (let boxCol = 0; boxCol < size; boxCol += sub.cols) {
      let count = 0;
      for (let row = boxRow; row < boxRow + sub.rows; row += 1) {
        for (let col = boxCol; col < boxCol + sub.cols; col += 1) {
          if (board[row][col] !== "") count += 1;
        }
      }
      if (count < config.box) return false;
    }
  }

  return true;
}

function getCandidates9x9(board, row, col) {
  if (board[row][col] !== "") return [];

  const symbols = SYMBOL_SETS[9];
  const used = new Set();

  for (let i = 0; i < 9; i += 1) {
    if (board[row][i] !== "") used.add(board[row][i]);
    if (board[i][col] !== "") used.add(board[i][col]);
  }

  const startRow = Math.floor(row / 3) * 3;
  const startCol = Math.floor(col / 3) * 3;

  for (let r = startRow; r < startRow + 3; r += 1) {
    for (let c = startCol; c < startCol + 3; c += 1) {
      if (board[r][c] !== "") used.add(board[r][c]);
    }
  }

  return symbols.filter((symbol) => !used.has(symbol));
}

function findBestEmptyCell9x9(board) {
  let best = null;

  for (let row = 0; row < 9; row += 1) {
    for (let col = 0; col < 9; col += 1) {
      if (board[row][col] !== "") continue;
      const candidates = getCandidates9x9(board, row, col);

      if (candidates.length === 0) return { row, col, candidates };
      if (!best || candidates.length < best.candidates.length) {
        best = { row, col, candidates };
      }
    }
  }

  return best;
}

function countSolutions9x9(board, limit = 2) {
  let count = 0;

  function backtrack() {
    if (count >= limit) return;

    const next = findBestEmptyCell9x9(board);
    if (!next) {
      count += 1;
      return;
    }

    const { row, col, candidates } = next;
    if (candidates.length === 0) return;

    for (const candidate of candidates) {
      board[row][col] = candidate;
      backtrack();
      board[row][col] = "";
      if (count >= limit) return;
    }
  }

  backtrack();
  return count;
}

function generateUniquePuzzle9x9(solution, removeCount, difficultyId) {
  const board = deepCopyGrid(solution);
  const config = getMinClueConfig(difficultyId);
  const cells = shuffle(
    Array.from({ length: 81 }, (_, index) => ({
      row: Math.floor(index / 9),
      col: index % 9,
    }))
  );

  let removed = 0;

  for (const { row, col } of cells) {
    if (removed >= removeCount) break;

    const backup = board[row][col];
    board[row][col] = "";

    if (!passesClueDistribution(board, config)) {
      board[row][col] = backup;
      continue;
    }

    const solutions = countSolutions9x9(deepCopyGrid(board), 2);
    if (solutions === 1) {
      removed += 1;
    } else {
      board[row][col] = backup;
    }
  }

  if (removed < removeCount) {
    const leftovers = shuffle(cells.filter(({ row, col }) => board[row][col] !== ""));

    for (const { row, col } of leftovers) {
      if (removed >= removeCount) break;

      const backup = board[row][col];
      board[row][col] = "";

      const solutions = countSolutions9x9(deepCopyGrid(board), 2);
      if (solutions === 1) {
        removed += 1;
      } else {
        board[row][col] = backup;
      }
    }
  }

  return board;
}

function generateBalancedPuzzle(solution, removeCount) {
  const size = solution.length;
  const board = deepCopyGrid(solution);
  const cells = [];

  for (let row = 0; row < size; row += 1) {
    for (let col = 0; col < size; col += 1) {
      cells.push({ row, col });
    }
  }

  shuffle(cells)
    .slice(0, removeCount)
    .forEach(({ row, col }) => {
      board[row][col] = "";
    });

  return board;
}

function generatePuzzle(solution, removeCount, difficultyId) {
  const size = solution.length;

  if (size === 9) {
    return generateUniquePuzzle9x9(solution, removeCount, difficultyId);
  }

  return generateBalancedPuzzle(solution, removeCount);
}

function updateResponsiveCellSize() {
  const size = state.board.length || getCurrentDifficulty().size;
  const viewportWidth = document.documentElement.clientWidth || window.innerWidth;
  const viewportHeight = document.documentElement.clientHeight || window.innerHeight;
  const isMobile = viewportWidth <= 760;
  const isSmallPhone = viewportWidth <= 430;
  const isLargeMobile = viewportWidth > 600 && viewportWidth <= 760;
  const isTablet = viewportWidth > 760 && viewportWidth <= 1180;
  const isDesktopShell = viewportWidth > 1180;

  const appWidth = Math.min(viewportWidth, 1640);
  const sideColumnWidth = isDesktopShell ? 252 : 0;
  const bodyPadding = isMobile ? (isSmallPhone ? 12 : 16) : Math.ceil(viewportWidth * 0.025);
  const centerPadding = isMobile ? 16 : 24;
  const gaps = isDesktopShell ? 14 : 0;
  const boardChrome = isMobile ? 12 : 22;

  const fallbackAvailableWidth = Math.max(
    appWidth - bodyPadding - sideColumnWidth - centerPadding - gaps - boardChrome,
    260
  );

  // Важное изменение: считаем размер поля не по примерной ширине окна,
  // а по реальной ширине контейнера boardWrap. Так поле расширяется вместе
  // с игровым блоком и не упирается в старый искусственный расчёт.
  const measuredBoardWrapWidth = dom.boardWrap?.clientWidth || 0;
  const availableWidth = Math.max(
    (measuredBoardWrapWidth > 120 ? measuredBoardWrapWidth - boardChrome : fallbackAvailableWidth),
    260
  );

  const maxByWidth = Math.floor(availableWidth / size);

  const getOuterHeight = (element) => {
    if (!element) return 0;

    const rect = element.getBoundingClientRect();
    const styles = window.getComputedStyle(element);

    return rect.height
      + (parseFloat(styles.marginTop) || 0)
      + (parseFloat(styles.marginBottom) || 0);
  };

  const getVerticalPadding = (element) => {
    if (!element) return 0;

    const styles = window.getComputedStyle(element);

    return (parseFloat(styles.paddingTop) || 0)
      + (parseFloat(styles.paddingBottom) || 0);
  };

  const modeRow = dom.modeBtn?.closest(".mode-row");
  const notesPanel = dom.notesBtn?.closest(".notes-panel");
  const center = document.querySelector(".center");
  const topbar = document.querySelector(".topbar");

  // В Яндекс Играх на десктопе снизу часто есть панель/рекомендации платформы.
  // Поэтому поле теперь ограничивается не только шириной, но и реальной высотой
  // экрана, чтобы вместе с цифрами и кнопкой заметок помещаться без скролла.
  const bottomPlatformReserve = isMobile ? 12 : (viewportHeight <= 950 ? 86 : 54);

  const measuredVerticalChrome =
    getOuterHeight(topbar)
    + getOuterHeight(modeRow)
    + getOuterHeight(document.querySelector(".board-head"))
    + getOuterHeight(dom.numberPad)
    + getOuterHeight(notesPanel)
    + getVerticalPadding(center)
    + getVerticalPadding(dom.boardWrap)
    + bodyPadding
    + bottomPlatformReserve;

  const fallbackVerticalChrome = size === 16
    ? (isTablet ? 430 : 430)
    : (isTablet ? 340 : 340);

  const verticalChrome = measuredVerticalChrome > 140
    ? measuredVerticalChrome
    : fallbackVerticalChrome;

  const availableHeight = Math.max(viewportHeight - verticalChrome, 220);
  const maxByHeight = Math.floor(availableHeight / size);

  let cellSize;
  if (isMobile) {
    // На телефоне учитываем высоту тоже, но с маленьким нижним запасом,
    // чтобы поле не прыгало из-за браузерных панелей.
    const visualMax = size === 16
      ? (isSmallPhone ? 24 : (isLargeMobile ? 36 : 30))
      : (isSmallPhone ? 44 : (isLargeMobile ? 74 : 60));
    const visualMin = size === 16 ? 18 : (isLargeMobile ? 38 : 32);

    cellSize = Math.max(visualMin, Math.min(maxByWidth, maxByHeight, visualMax));
  } else {
    // На широких экранах поле всё ещё может расти, но теперь не ценой
    // вертикального скролла основных игровых элементов.
    const visualMax = size === 16
      ? (isTablet ? 44 : 48)
      : (isTablet ? 82 : 92);
    const visualMin = size === 16 ? 22 : 36;

    cellSize = Math.max(visualMin, Math.min(maxByWidth, maxByHeight, visualMax));
  }

  document.documentElement.style.setProperty("--cell-size", `${cellSize}px`);
  document.body.dataset.boardSize = String(size);
}
function updateModeButton() {
  const diff = getCurrentDifficulty();
  const unlocked = isCurrentEndlessUnlocked();

  if (!unlocked) {
    dom.modeBtn.disabled = true;
    dom.modeBtn.classList.remove("active", "paused-locked");
    dom.modeBtn.classList.add("locked");
    dom.modeBtnMeta.textContent = t("opensAfter5Wins");
    dom.modeBtnBadge.textContent = t("locked");
    return;
  }

  if (state.isPaused) {
    dom.modeBtn.disabled = true;
    dom.modeBtn.classList.remove("active", "locked");
    dom.modeBtn.classList.add("paused-locked");
    dom.modeBtnMeta.textContent = t("resume");
    dom.modeBtnBadge.textContent = t("pause");
    return;
  }

  dom.modeBtn.disabled = false;
  dom.modeBtn.classList.remove("locked", "paused-locked");
  dom.modeBtnMeta.textContent = t("noLivesCheckAtEnd");

  if (state.isEndless) {
    dom.modeBtn.classList.add("active");
    dom.modeBtnBadge.textContent = t("on");
  } else {
    dom.modeBtn.classList.remove("active");
    dom.modeBtnBadge.textContent = t("off");
  }
}

function updateThemeButton() {
  const current = document.body.getAttribute("data-theme") || "dark";
  dom.themeBtn.classList.add("theme-switch");
  dom.themeBtn.classList.add("active");
  //dom.themeBtnMeta.textContent = "Переключение светлой и тёмной темы";
  dom.themeBtnBadge.textContent = current === "light" ? t("lightTheme") : t("darkTheme");
}

function updateLanguageButton() {
  if (!dom.langBtn) return;
  if (dom.langBtnMeta) {
    dom.langBtnMeta.textContent = t("langMeta");
  }
  if (dom.langBtnBadge) {
    dom.langBtnBadge.textContent = t("langBadge");
  }
  dom.langBtn.setAttribute("aria-label", `RU / EN: ${t("langMeta")}`);
}

function refreshLanguageInterface() {
  applyLanguage(currentLang);
  updateBoardTexts();
  updateHintMeta();
  updateModeButton();
  updateThemeButton();
  updateLanguageButton();
  updateSecondaryStat();
  updateNotesButton();
  updatePauseButton();
  renderDifficultyList();
  renderProgress();
}

function toggleLanguage() {
  const nextLang = currentLang === "ru" ? "en" : "ru";
  localStorage.setItem(STORAGE_KEYS.lang, nextLang);
  currentLang = nextLang;
  refreshLanguageInterface();
}

function updateSecondaryStat() {
  if (state.isEndless) {
    dom.modeStatLabel.textContent = t("mode");
    dom.modeValue.textContent = "∞";
    dom.modeValue.classList.remove("lives");
  } else {
    dom.modeStatLabel.textContent = t("lives");
    const hearts = Array.from({ length: Math.max(state.lives, 0) }, () => "❤").join(" ");
    dom.modeValue.textContent = hearts || "—";
    dom.modeValue.classList.add("lives");
  }
}

function initGame() {
  hideAllModals();
  state.gameOver = false;
  state.isPaused = false;
  state.pauseReason = null;
  state.lives = 3;
  state.selected = null;
  state.notesMode = false;
  state.timerSeconds = 0;
  state.timerStarted = false;
  state.hintsUsedThisGame = 0;
  state.surrendered = false;

  if (state.isEndless && !isCurrentEndlessUnlocked()) {
    state.isEndless = false;
  }

  updateTimerText();
  updateCoins();
  updateNotesButton();
  updateHintMeta();
  updateModeButton();
  updateThemeButton();
  updateLanguageButton();
  updatePauseButton();
  updateActionButtons();
  updateSecondaryStat();
  stopTimer();

  const diff = getCurrentDifficulty();
  state.solution = generateSolvedBoard(diff.size);
  state.board = generatePuzzle(state.solution, diff.removeCount, diff.id);
  state.fixed = state.board.map((row) => row.map((value) => value !== ""));
  state.notes = createEmptyNotes(diff.size);

  // Важно: сначала обновляем DOM, который влияет на высоту/ширину интерфейса,
  // и только потом считаем размер клеток. Иначе при переключении 9×9 ↔ 16×16
  // размер поля считался по старой панели цифр/старому заголовку и начинал прыгать.
  updateBoardTexts();
  renderDifficultyList();
  renderProgress();
  renderNumberPad();
  updateResponsiveCellSize();
  renderBoard();

  // Второй проход после фактической раскладки браузером. Это убирает расхождение
  // между первым запуском сложности и повторным нажатием на ту же сложность.
  requestAnimationFrame(() => {
    updateResponsiveCellSize();
    renderBoard();
  });
}

function updateBoardTexts() {
  const diff = getCurrentDifficulty();
  const modeText = state.isEndless ? ` · ${t("endlessShort")}` : "";
  dom.boardTitle.textContent = `${getDifficultyTitle(diff)} · ${t("field")} ${diff.size}×${diff.size}${modeText}`;
  dom.boardSubtitle.textContent = state.isEndless
    ? `${getDifficultyDescription(diff)} ${t("endlessSuffix")}`
    : getDifficultyDescription(diff);
}

function updateHintMeta() {
  if (state.hintsUsedThisGame === 0) {
    dom.hintMeta.textContent = t("firstHintFree");
  } else {
    dom.hintMeta.textContent = t("nextHint");
  }
}

function renderDifficultyList() {
  dom.difficultyList.innerHTML = "";

  DIFFICULTIES.forEach((diff, index) => {
    const unlocked = isDifficultyUnlocked(index);
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `difficulty-item ${index === state.difficultyIndex ? "active" : ""} ${unlocked ? "" : "locked"} ${state.isPaused ? "paused-locked" : ""}`;
    btn.disabled = state.isPaused;
    btn.innerHTML = `
      <div class="difficulty-main">
        <div>
          <div class="difficulty-name">${getDifficultyTitle(diff)}</div>
          <div class="difficulty-meta">${diff.size}×${diff.size}</div>
        </div>
        <div class="difficulty-badge">${unlocked ? `${diff.reward} ${t("coinsShort")}` : `${getDifficultyProgressText(index)}`}</div>
      </div>
    `;
    btn.addEventListener("click", () => {
      if (state.isPaused) return;
      if (!unlocked) return;

      // Если нажали на уже выбранную сложность — ничего не пересоздаём.
      // Раньше активная кнопка заново запускала initGame(), генерировала новое поле
      // и повторно пересчитывала размер. Из-за этого казалось, что интерфейс скачет
      // даже без реальной смены сложности.
      if (index === state.difficultyIndex) return;

      state.difficultyIndex = index;
      if (state.isEndless && !isCurrentEndlessUnlocked()) {
        state.isEndless = false;
      }
      initGame();
    });
    dom.difficultyList.appendChild(btn);
  });
}

function renderProgress() {
  dom.progressList.innerHTML = "";

  DIFFICULTIES.forEach((diff, index) => {
    const item = document.createElement("div");
    const wins = state.progress[diff.id] || 0;
    const unlocked = isDifficultyUnlocked(index);
    const fullyOpened = index === 0 || unlocked;
    const endlessText = wins >= 5 ? t("endlessOpen") : `${Math.min(wins, 5)}/5 ${t("toInfinity")}`;

    item.className = `progress-item ${wins > 0 ? "done" : ""}`;
    item.innerHTML = `
      <div class="progress-main">
        <div>
          <div class="progress-name">${getDifficultyTitle(diff)}</div>
          <div class="progress-meta">${fullyOpened ? `${t("wins")}: ${wins}` : t("needUnlock")}</div>
        </div>
        <div class="progress-badge">${fullyOpened ? endlessText : `${getDifficultyProgressText(index)}`}</div>
      </div>
    `;
    dom.progressList.appendChild(item);
  });
}

function getCellSectorClass(size, row, col) {
  const sub = SUBGRID_MAP[size];
  const sectorRow = Math.floor(row / sub.rows);
  const sectorCol = Math.floor(col / sub.cols);
  return (sectorRow + sectorCol) % 2 === 0 ? "sector-a" : "sector-b";
}

function isRelatedCell(row, col, selectedRow, selectedCol) {
  const size = state.board.length;
  const bounds = getSubgridBounds(size, selectedRow, selectedCol);

  return (
    row === selectedRow ||
    col === selectedCol ||
    (
      row >= bounds.startRow &&
      row <= bounds.endRow &&
      col >= bounds.startCol &&
      col <= bounds.endCol
    )
  );
}

function renderBoard() {
  const size = state.board.length;
  const sub = SUBGRID_MAP[size];
  const selectedValue = state.selected
    ? state.board[state.selected.row][state.selected.col]
    : "";

  dom.board.innerHTML = "";
  dom.board.style.gridTemplateColumns = `repeat(${size}, var(--cell-size))`;

  for (let row = 0; row < size; row += 1) {
    for (let col = 0; col < size; col += 1) {
      const value = state.board[row][col];
      const cell = document.createElement("div");
      cell.className = `cell ${getCellSectorClass(size, row, col)}`;
      cell.dataset.row = String(row);
      cell.dataset.col = String(col);

      if (row % sub.rows === 0) cell.classList.add("thick-top");
      if (col % sub.cols === 0) cell.classList.add("thick-left");
      if (row === size - 1) cell.classList.add("thick-bottom");
      if (col === size - 1) cell.classList.add("thick-right");

      if (state.fixed[row][col]) {
        cell.classList.add("fixed");
      } else {
        cell.classList.add("editable");
      }

      if (state.selected && row === state.selected.row && col === state.selected.col) {
        cell.classList.add("selected");
      } else if (state.selected && isRelatedCell(row, col, state.selected.row, state.selected.col)) {
        cell.classList.add("related");
      }

      if (
        selectedValue &&
        value &&
        value === selectedValue &&
        (!state.selected || row !== state.selected.row || col !== state.selected.col)
      ) {
        cell.classList.add("same-value");
      }

      if (value) {
        cell.textContent = value;
      } else {
        renderNotesIntoCell(cell, row, col);
      }

      if (state.notesMode && state.selected && row === state.selected.row && col === state.selected.col) {
        cell.classList.add("notes-mode-preview");
      }

      cell.addEventListener("click", () => {
        if (state.isPaused || state.gameOver) return;
        state.selected = { row, col };
        renderBoard();
      });

      dom.board.appendChild(cell);
    }
  }
}

function renderNotesIntoCell(cell, row, col) {
  const size = state.board.length;
  const notes = Array.from(state.notes[row][col]).sort(
    (a, b) => getSymbols(size).indexOf(a) - getSymbols(size).indexOf(b)
  );

  if (!notes.length) {
    cell.textContent = "";
    return;
  }

  const symbols = getSymbols(size);
  const columns = size === 16 ? 4 : size === 4 ? 2 : 3;

  const notesGrid = document.createElement("div");
  notesGrid.className = "notes-grid";
  notesGrid.style.gridTemplateColumns = `repeat(${columns}, 1fr)`;
  notesGrid.style.gridTemplateRows = `repeat(${Math.ceil(symbols.length / columns)}, 1fr)`;

  symbols.forEach((symbol) => {
    const noteEl = document.createElement("span");
    noteEl.className = "note-item";
    noteEl.textContent = notes.includes(symbol) ? symbol : "";
    notesGrid.appendChild(noteEl);
  });

  cell.appendChild(notesGrid);
}

function renderNumberPad() {
  const size = state.board.length;
  const symbols = getSymbols(size);
  dom.numberPad.innerHTML = "";

  dom.numberPad.style.gridTemplateColumns =
    size <= 9
      ? (window.innerWidth < 760 ? "repeat(3, minmax(0, 1fr))" : "repeat(9, minmax(0, 1fr))")
      : (window.innerWidth < 760 ? "repeat(4, minmax(0, 1fr))" : "repeat(8, minmax(0, 1fr))");

  symbols.forEach((symbol) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "number-btn";
    btn.textContent = symbol;

    if (isSymbolCompleted(symbol)) {
      btn.classList.add("completed");
    }

    btn.addEventListener("click", () => handleSymbolInput(symbol));
    dom.numberPad.appendChild(btn);
  });
}

function isSymbolCompleted(symbol) {
  const size = state.board.length;
  let correctCount = 0;

  for (let row = 0; row < size; row += 1) {
    for (let col = 0; col < size; col += 1) {
      if (state.board[row][col] === symbol && state.solution[row][col] === symbol) {
        correctCount += 1;
      }
    }
  }

  return correctCount === size;
}

function updateNotesButton() {
  dom.notesBtn.textContent = state.notesMode ? t("notesOn") : t("notesOff");
  dom.notesBtn.classList.toggle("active", state.notesMode);
  dom.notesBtn.disabled = state.isPaused;
}

function updatePauseButton() {
  if (!dom.pauseBtn) return;
  dom.pauseBtn.textContent = state.isPaused ? t("resume") : t("pause");
  dom.pauseBtn.classList.toggle("active", state.isPaused);
}

function updateActionButtons() {
  const disabled = state.isPaused;

  [
    dom.newGameBtn,
    dom.eraseBtn,
    dom.clearNotesBtn,
    dom.hintBtn,
    dom.surrenderBtn,
  ].forEach((button) => {
    if (!button) return;
    button.disabled = disabled;
    button.classList.toggle("paused-locked", disabled);
  });
}

function showNotification(message, type = "warning") {
  if (!dom.notification) return;

  clearTimeout(showNotification.timerId);
  dom.notification.textContent = message;
  dom.notification.className = `notification ${type}`;
  dom.notification.classList.remove("hidden");

  showNotification.timerId = setTimeout(() => {
    dom.notification.classList.add("hidden");
  }, 2300);
}

function setGameplayActive(active) {
  if (!window.YandexStorage) return;

  if (active) {
    window.YandexStorage.startGameplay?.();
  } else {
    window.YandexStorage.stopGameplay?.();
  }
}

function pauseGame(reason = "manual") {
  if (state.gameOver || state.isPaused) return;
  state.isPaused = true;
  state.pauseReason = reason;
  stopTimer();
  setGameplayActive(false);
  updatePauseButton();
  updateActionButtons();
  updateNotesButton();
  updateModeButton();
  renderDifficultyList();
  dom.boardWrap?.classList.add("paused");
}

function resumeGame(reason = "manual") {
  if (!state.isPaused) return;
  state.isPaused = false;
  state.pauseReason = null;
  if (state.timerStarted && !state.gameOver) {
    startTimer();
    setGameplayActive(true);
  }
  updatePauseButton();
  updateActionButtons();
  updateNotesButton();
  updateModeButton();
  renderDifficultyList();
  dom.boardWrap?.classList.remove("paused");
}

function togglePause() {
  if (state.isPaused) {
    resumeGame("manual");
  } else {
    pauseGame("manual");
  }
}

function updateTimerText() {
  const minutes = Math.floor(state.timerSeconds / 60);
  const seconds = state.timerSeconds % 60;
  const timeText = `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  dom.timeValue.textContent = timeText;
  if (dom.mobileTimeValue) dom.mobileTimeValue.textContent = timeText;
}

function startTimer() {
  if (state.gameOver || state.isPaused || state.timerId) {
    return;
  }

  state.timerId = setInterval(() => {
    if (!state.gameOver && !state.isPaused) {
      state.timerSeconds += 1;
      updateTimerText();
    }
  }, 1000);
}

function stopTimer() {
  if (state.timerId) {
    clearInterval(state.timerId);
    state.timerId = null;
  }
}

function updateCoins() {
  dom.coinsValue.textContent = String(state.coins);
  dom.modalCoinsValue.textContent = String(state.coins);
}

function handleSymbolInput(symbol) {
  if (!state.selected || state.gameOver || state.isPaused) return;

  const { row, col } = state.selected;
  if (state.fixed[row][col]) {
    renderBoard();
    return;
  }

  if (state.notesMode) {
    toggleNote(row, col, symbol);
    renderBoard();
    return;
  }

  setCellValue(row, col, symbol);
}

function toggleNote(row, col, symbol) {
  if (state.board[row][col] !== "") return;

  const notesSet = state.notes[row][col];
  if (notesSet.has(symbol)) {
    notesSet.delete(symbol);
  } else {
    notesSet.add(symbol);
  }
}

function isBoardFilled() {
  for (let row = 0; row < state.board.length; row += 1) {
    for (let col = 0; col < state.board.length; col += 1) {
      if (state.board[row][col] === "") {
        return false;
      }
    }
  }
  return true;
}

function countBoardErrors() {
  let errors = 0;

  for (let row = 0; row < state.board.length; row += 1) {
    for (let col = 0; col < state.board.length; col += 1) {
      if (state.board[row][col] !== state.solution[row][col]) {
        errors += 1;
      }
    }
  }

  return errors;
}

function checkEndlessCompletion() {
  if (!isBoardFilled()) return;

  const errors = countBoardErrors();

  if (errors === 0) {
    state.gameOver = true;
    stopTimer();
    setGameplayActive(false);
    dom.endlessResultText.textContent = t("endlessPerfect");
    dom.continueEndlessBtn.classList.add("hidden");
    showModal(dom.endlessResultModal);
    return;
  }

  dom.endlessResultText.textContent = t("endlessErrors", errors);
  dom.continueEndlessBtn.classList.remove("hidden");
  showModal(dom.endlessResultModal);
}

function setCellValue(row, col, value) {
  
  if (!state.timerStarted) {
    state.timerStarted = true;
    startTimer();
    setGameplayActive(true);
  } 
  state.notes[row][col].clear();

  if (state.isEndless) {
    state.board[row][col] = value;
    renderBoard();
    renderNumberPad();
    checkEndlessCompletion();
    return;
  }

  if (value === state.solution[row][col]) {
    state.board[row][col] = value;
    renderBoard();
    renderNumberPad();
    checkWin();
    return;
  }

  state.board[row][col] = value;
  renderBoard();
  markCellInvalid(row, col);

  setTimeout(() => {
    if (state.board[row][col] === value && state.solution[row][col] !== value) {
      state.board[row][col] = "";
      renderBoard();
    }
  }, 380);

  state.lives -= 1;
  updateSecondaryStat();
  renderNumberPad();

  if (state.lives <= 0) {
    state.lives = 0;
    updateSecondaryStat();
    loseGame();
  }
}

function markCellInvalid(row, col) {
  const selector = `.cell[data-row="${row}"][data-col="${col}"]`;
  const cell = dom.board.querySelector(selector);
  if (cell) {
    cell.classList.add("invalid");
  }
}

function eraseSelected() {
  if (!state.selected || state.gameOver || state.isPaused) return;

  const { row, col } = state.selected;
  if (state.fixed[row][col]) return;

  if (state.notesMode) {
    state.notes[row][col].clear();
  } else {
    state.board[row][col] = "";
    state.notes[row][col].clear();
  }

  renderBoard();
  renderNumberPad();
}

function clearSelectedNotes() {
  if (!state.selected || state.gameOver || state.isPaused) return;

  const { row, col } = state.selected;
  if (state.fixed[row][col]) return;

  state.notes[row][col].clear();
  renderBoard();
}

function useHint() {
  if (state.gameOver || state.isPaused) return;

  const price = state.hintsUsedThisGame === 0 ? 0 : 25;
  if (price > 0 && state.coins < price) {
    showNotification(t("notEnoughCoinsHint"), "warning");
    return;
  }

  const candidates = [];
  for (let row = 0; row < state.board.length; row += 1) {
    for (let col = 0; col < state.board.length; col += 1) {
      if (state.board[row][col] !== state.solution[row][col]) {
        candidates.push({ row, col });
      }
    }
  }

  if (!candidates.length) return;

  const target = shuffle(candidates)[0];
  const { row, col } = target;

  if (price > 0) {
    state.coins -= price;
    saveCoins();
    updateCoins();
  }

  state.board[row][col] = state.solution[row][col];
  state.notes[row][col].clear();
  state.selected = { row, col };
  state.hintsUsedThisGame += 1;
  updateHintMeta();
  renderBoard();
  renderNumberPad();

  if (state.isEndless) {
    checkEndlessCompletion();
  } else {
    checkWin();
  }
}

function surrenderGame() {
  if (state.gameOver || state.isPaused) return;

  state.surrendered = true;
  state.gameOver = true;
  stopTimer();
  setGameplayActive(false);

  state.board = deepCopyGrid(state.solution);
  state.notes = createEmptyNotes(state.board.length);
  renderBoard();
  renderNumberPad();

  dom.overlay.classList.add("hidden");
  dom.surrenderModal.classList.remove("hidden");
}

function loseGame() {
  state.gameOver = true;
  stopTimer();
  setGameplayActive(false);
  showModal(dom.gameOverModal);
}

function checkWin() {
  const size = state.board.length;

  for (let row = 0; row < size; row += 1) {
    for (let col = 0; col < size; col += 1) {
      if (state.board[row][col] !== state.solution[row][col]) {
        return;
      }
    }
  }

  const diff = getCurrentDifficulty();
  state.progress[diff.id] = (state.progress[diff.id] || 0) + 1;
  saveProgress();

  state.coins += diff.reward;
  saveCoins();
  updateCoins();
  renderProgress();
  renderDifficultyList();
  updateModeButton();

  state.gameOver = true;
  stopTimer();
  setGameplayActive(false);

  const winsOnCurrent = state.progress[diff.id] || 0;
  const nextIndex = Math.min(state.difficultyIndex + 1, DIFFICULTIES.length - 1);
  const hasNext = nextIndex > state.difficultyIndex;
  const nextUnlocked = hasNext ? isDifficultyUnlocked(nextIndex) : false;

  dom.winText.textContent =
    t("winMessage", getDifficultyTitle(diff), diff.reward, winsOnCurrent);

  if (hasNext && nextUnlocked && winsOnCurrent >= 5) {
    dom.nextDifficultyBtn.textContent = t("nextLevel");
    dom.nextDifficultyBtn.classList.remove("hidden");
    dom.restartAfterWinBtn.classList.add("hidden");
  } else {
    dom.nextDifficultyBtn.classList.add("hidden");
    dom.restartAfterWinBtn.classList.remove("hidden");
    dom.restartAfterWinBtn.textContent = t("playAgain");
  }

  showModal(dom.winModal);
}

function showModal(modal) {
  if (modal === dom.surrenderModal) {
    dom.overlay.classList.add("hidden");
  } else {
    dom.overlay.classList.remove("hidden");
  }

  modal.classList.remove("hidden");
}

function hideAllModals() {
  dom.overlay.classList.add("hidden");
  dom.gameOverModal.classList.add("hidden");
  dom.winModal.classList.add("hidden");
  dom.surrenderModal.classList.add("hidden");
  dom.endlessResultModal.classList.add("hidden");
  dom.rulesModal?.classList.add("hidden");
}

function closeRulesModal() {
  dom.overlay.classList.add("hidden");
  dom.rulesModal?.classList.add("hidden");
}

function openRulesModal() {
  if (!dom.rulesModal) return;
  showModal(dom.rulesModal);
}

function buyLife() {
  if (state.coins < 50) {
    showNotification(t("notEnoughCoinsContinue"), "warning");
    return;
  }

  state.coins -= 50;
  state.lives += 1;
  saveCoins();
  updateCoins();
  updateSecondaryStat();
  state.gameOver = false;
  state.isPaused = false;
  state.pauseReason = null;
  hideAllModals();
  updatePauseButton();
  updateNotesButton();
  startTimer();
  setGameplayActive(true);
}

function goToNextDifficulty() {
  const nextIndex = Math.min(state.difficultyIndex + 1, DIFFICULTIES.length - 1);
  if (isDifficultyUnlocked(nextIndex) && nextIndex !== state.difficultyIndex) {
    state.difficultyIndex = nextIndex;
  }
  state.isEndless = false;
  initGame();
}

function toggleGameMode() {
  if (state.isPaused) return;

  if (!isCurrentEndlessUnlocked()) {
    const diff = getCurrentDifficulty();
    showNotification(t("endlessLockedMessage", getDifficultyTitle(diff)), "warning");
    return;
  }

  state.isEndless = !state.isEndless;
  initGame();
}

function continueEndlessEditing() {
  hideAllModals();
  state.gameOver = false;
  state.isPaused = false;
  state.pauseReason = null;
  updatePauseButton();
  updateNotesButton();
}

function applyTheme(theme) {
  document.body.setAttribute("data-theme", theme);
  localStorage.setItem("sudoku_theme", theme);
  updateThemeButton();
  syncYandexSave();
}

function initTheme() {
  const saved = localStorage.getItem("sudoku_theme") || "dark";
  applyTheme(saved);
}

function isScrollableElement(element, deltaY) {
  let node = element;

  while (node && node !== document.body && node !== document.documentElement) {
    const style = window.getComputedStyle(node);
    const canScrollY = /(auto|scroll)/.test(style.overflowY) && node.scrollHeight > node.clientHeight;

    if (canScrollY) {
      if (deltaY < 0 && node.scrollTop > 0) return true;
      if (deltaY > 0 && node.scrollTop + node.clientHeight < node.scrollHeight - 1) return true;
    }

    node = node.parentElement;
  }

  return false;
}

function installInteractionGuards() {
  const guardedSelector = ".app, .modal, .overlay, .notification";
  let touchStartY = 0;

  ["contextmenu", "selectstart", "dragstart"].forEach((eventName) => {
    document.addEventListener(eventName, (event) => {
      if (event.target.closest?.(guardedSelector) || event.target === document.body) {
        event.preventDefault();
      }
    }, { capture: true });
  });

  document.addEventListener("touchstart", (event) => {
    if (event.touches.length === 1) {
      touchStartY = event.touches[0].clientY;
    }
  }, { passive: false, capture: true });

  document.addEventListener("touchmove", (event) => {
    if (event.touches.length !== 1) {
      event.preventDefault();
      return;
    }

    const currentY = event.touches[0].clientY;
    const deltaY = touchStartY - currentY;
    const scrollable = isScrollableElement(event.target, deltaY);

    if (!scrollable) {
      event.preventDefault();
    }
  }, { passive: false, capture: true });

  document.addEventListener("gesturestart", (event) => event.preventDefault(), { passive: false });
}

function bindEvents() {
  dom.notesBtn.addEventListener("click", () => {
    if (state.isPaused || state.gameOver) return;
    state.notesMode = !state.notesMode;
    updateNotesButton();
    renderBoard();
  });

  dom.newGameBtn.addEventListener("click", () => {
    if (state.isPaused) return;
    initGame();
  });
  dom.pauseBtn?.addEventListener("click", togglePause);
  dom.modeBtn.addEventListener("click", toggleGameMode);
  dom.langBtn?.addEventListener("click", toggleLanguage);
  dom.rulesBtn?.addEventListener("click", openRulesModal);
  dom.closeRulesBtn?.addEventListener("click", closeRulesModal);
  dom.themeBtn.addEventListener("click", () => {
    const current = document.body.getAttribute("data-theme") || "dark";
    applyTheme(current === "light" ? "dark" : "light");
  });

  dom.eraseBtn.addEventListener("click", () => {
    if (state.isPaused) return;
    eraseSelected();
  });
  dom.clearNotesBtn.addEventListener("click", () => {
    if (state.isPaused) return;
    clearSelectedNotes();
  });
  dom.hintBtn.addEventListener("click", () => {
    if (state.isPaused) return;
    useHint();
  });
  dom.surrenderBtn.addEventListener("click", () => {
    if (state.isPaused) return;
    surrenderGame();
  });

  dom.buyLifeBtn.addEventListener("click", buyLife);
  dom.restartFromLoseBtn.addEventListener("click", initGame);
  dom.nextDifficultyBtn.addEventListener("click", goToNextDifficulty);
  dom.restartAfterWinBtn.addEventListener("click", initGame);
  dom.restartAfterSurrenderBtn.addEventListener("click", initGame);
  dom.continueEndlessBtn.addEventListener("click", continueEndlessEditing);
  dom.restartAfterEndlessBtn.addEventListener("click", initGame);

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && dom.rulesModal && !dom.rulesModal.classList.contains("hidden")) {
      closeRulesModal();
      return;
    }

    if (event.key.toLowerCase() === "o" && DEBUG_MODE) {
      state.debugUnlockAll = !state.debugUnlockAll;

      console.log("DEBUG unlock:", state.debugUnlockAll);

      renderDifficultyList();
      renderProgress();
      updateModeButton();

      return;
    }

    if (event.key.toLowerCase() === "n") {
      if (state.isPaused || state.gameOver) return;
      state.notesMode = !state.notesMode;
      updateNotesButton();
      renderBoard();
      return;
    }

    if (state.isPaused) return;

    if (event.key === "Backspace" || event.key === "Delete") {
      eraseSelected();
      return;
    }

    const size = state.board.length;
    const symbols = getSymbols(size);
    const key = event.key.toUpperCase();

    if (symbols.includes(key)) {
      handleSymbolInput(key);
    }
  });

  let lastResponsiveWidth = document.documentElement.clientWidth || window.innerWidth;
  window.addEventListener("resize", () => {
    const currentWidth = document.documentElement.clientWidth || window.innerWidth;
    const widthChanged = Math.abs(currentWidth - lastResponsiveWidth) > 8;
    const isMobile = currentWidth <= 760;

    // На мобильных браузерные панели могут появляться/исчезать после тапа и менять
    // только высоту viewport. Игнорируем такие resize, чтобы поле не прыгало.
    if (isMobile && !widthChanged) return;

    lastResponsiveWidth = currentWidth;

    // Сначала панель цифр, потом размер поля. Иначе при переходе 9×9/16×16
    // высота панели цифр учитывалась от прошлого режима.
    renderNumberPad();
    requestAnimationFrame(() => {
      updateResponsiveCellSize();
      renderBoard();
    });
  });
}

async function syncYandexSave() {
  if (!window.YandexStorage) return;

  const theme = localStorage.getItem("sudoku_theme") || "dark";

  await window.YandexStorage.saveGameState({
    coins: state.coins,
    progress: state.progress,
    theme,
  });
}

async function bootstrapGame() {
  if (window.YandexStorage) {
    await window.YandexStorage.init();
  }

  const defaultTheme = localStorage.getItem("sudoku_theme") || "dark";

  const defaultState = {
    coins: loadCoins(),
    progress: loadProgress(),
    theme: defaultTheme,
  };

  if (window.YandexStorage) {
    const loaded = await window.YandexStorage.loadGameState(defaultState);

    state.coins = loaded.coins;
    state.progress = loaded.progress;

    localStorage.setItem(STORAGE_KEYS.coins, String(loaded.coins));
    localStorage.setItem(STORAGE_KEYS.progress, JSON.stringify(loaded.progress));
    localStorage.setItem("sudoku_theme", loaded.theme);
  }

  if (window.YandexStorage && !hasExplicitLanguageOverride()) {
    const sdkLang = window.YandexStorage.getLanguage?.();
    if (sdkLang) currentLang = normalizeLang(sdkLang);
  }

  applyLanguage(currentLang);
  initTheme();
  installInteractionGuards();
  bindEvents();
  initGame();

  // Яндекс Игры дорисовывает свои панели/рекламу не всегда синхронно с загрузкой iframe.
  // Делаем пару мягких пересчётов после старта, чтобы стартовый размер поля совпадал
  // с размером после первого клика по сложности.
  [100, 350, 800].forEach((delay) => {
    window.setTimeout(() => {
      renderNumberPad();
      updateResponsiveCellSize();
      renderBoard();
    }, delay);
  });

  if (window.YandexStorage) {
    window.YandexStorage.onPause?.(() => pauseGame("platform"));
    window.YandexStorage.onResume?.(() => resumeGame("platform"));
  }

  if (window.YandexStorage) {
    await window.YandexStorage.ready();
  }
}

bootstrapGame();